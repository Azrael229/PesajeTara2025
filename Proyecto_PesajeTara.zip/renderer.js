// renderer.js
const btn = document.getElementById('btnAgregar');
const mensaje = document.getElementById('mensaje');

btn.addEventListener('click', () => {
  const nombre = document.getElementById('nombre').value;
  const rol = document.getElementById('rol').value;
  const password = document.getElementById('password').value;

  if (!nombre || !rol || !password) {
    mensaje.textContent = "Todos los campos son obligatorios";
    return;
  }

  // Enviamos los datos al Main a través del preload
  // @ts-ignore
  window.electronAPI.insertUsuario({ nombre, rol, password });

  mensaje.textContent = "Usuario enviado para agregar...";
});

// Recibir confirmación desde Main
window.electronAPI.onUsuarioAgregado((data) => {
  mensaje.textContent = `Usuario agregado: ${data.nombre}`;

  // Limpiar inputs
  document.getElementById('nombre').value = '';
  document.getElementById('rol').value = '';
  document.getElementById('password').value = '';
});
